# Laboratorio 2 — Filtro FIR con Perturbación Coherente (S = 43, ADC0808)

Electrónica Digital II, UPTC Tunja. Implementación sobre FPGA DE1 (Cyclone II),
adaptada al conversor **ADC0808** (8 bits, paralelo) y a un **DAC R-2R de 8
bits**, con el parámetro individual **S = 43**.

Fuentes usadas (carpetas de tu proyecto): `Laboratorio2_Filtro_FIR_
Perturbacion_Coherente.pdf`, `Guia_FIR_FilterDesigner_v5.pdf` y
`Presentacion_Laboratorio2_FIR.pdf`. Cada archivo `.vhd` indica en su cabecera
si el código es una reproducción literal de una fuente o una adaptación
propia, y por qué.

## Estado del proyecto — LEE ESTO PRIMERO

Todo el VHDL de este proyecto **compila, elabora y simula correctamente con
GHDL 4.1** (comandos exactos más abajo), incluyendo la integración completa
en `top.vhd`. Sin embargo, **todavía no es un filtro real**: `FIR_Filter.vhd`
trae los 27 coeficientes en cero, a la espera de que diseñes el filtro en
MATLAB. Hasta que los reemplaces, la salida filtrada es siempre cero.

Lo que falta, en orden:

1. Diseñar el filtro en MATLAB Filter Designer (Etapa 6 de tu propio plan).
2. Ejecutar `matlab/exportar_coeficientes_S43.m` → genera `coeficientes.txt`.
3. Pegar ese bloque en `vhdl/FIR_Filter.vhd` y actualizar `FILTER_TAPS` ahí
   **y** en `vhdl/FIR_Filter_tb.vhd`.
4. Ejecutar `matlab/modelo_referencia_S43.m` → genera `in.txt`/`ref.txt`.
5. Simular `FIR_Filter_tb.vhd` con esos archivos y confirmar diferencia 0 LSB.
6. Verificar con multímetro la ganancia real del LM358 (nominal 10) y el
   fondo de escala real del ADC0808 (VREF+/VREF−); recalcular K y SH en
   `top.vhd` si no coinciden con los valores nominales usados aquí (V_fs=5V).
7. Asignar los pines físicos reales en Quartus (Pin Planner / Assignment
   Editor) siguiendo la tabla de este README — **no vienen ya asignados**,
   porque las fuentes no dan números de pin de la FPGA, solo posiciones
   dentro del conector GPIO_0.
8. Simular `top.vhd` con el DIV_FS real (62500), aunque sea una vez, para
   confirmar que no hay overflow (no debería haberlo: los contadores están
   declarados con rango exacto).

## 1. Objetivo

Adquirir una señal de temperatura (LM35) contaminada deliberadamente con una
perturbación coherente conocida, eliminar esa perturbación con un filtro FIR
diseñado a medida en la FPGA, y comparar en el osciloscopio la señal cruda
contra la filtrada. La perturbación se genera y se sincroniza con el propio
muestreo, así que sus armónicos caen siempre en múltiplos conocidos y el
diseño del filtro es determinista.

## 2. Parámetros de S = 43 (Etapa 1)

| Parámetro | Valor |
|---|---|
| Fs (frecuencia de muestreo) | 800 Hz |
| DIV_FS | 62 500 (par ✓) |
| f_n (perturbación, posición de diseño r=4) | 200 Hz |
| Fpass | 25 Hz |
| Fstop | 200 Hz |
| Fc (a introducir en el Filter Designer) | 112,5 Hz |
| Número de coeficientes | entre 23 y 33 (exacto: a determinar en MATLAB) |
| ADC | ADC0808, 8 bits, Configuración B (5 V) |
| DAC | R-2R, 8 bits |
| K, SH (preliminares, ver README §6) | K = 2209, SH = 10 |

(Cálculo completo, con cada paso, en la conversación donde se generó este
proyecto — Etapa 1.)

## 3. Arquitectura

```
LM35 -> LM358 (ganancia 10, alimentado a 5V) -> perturbacion coherente (pert)
     -> ADC0808 -> FPGA (gen_muestreo, adc0808_reader, FIR_Filter)
     -> DAC R-2R -> osciloscopio
                 -> displays HEX3..HEX0 (temperatura o codigo crudo)
```

Dentro de la FPGA (ver comentarios en `vhdl/top.vhd`):

```
top.vhd
├── gen_muestreo   -> fsclk, latido (GPIO_0[1]), pert (GPIO_0[0])
├── adc0808_reader -> gobierna el ADC0808 (GPIO_0[2..14]); dispara con fsclk
├── FIR_Filter     -> filtra el dato del ADC; dispara con valid_o del ADC
├── mux SW(2)       -> cruda o filtrada hacia el DAC y hacia el escalado
├── escalado K/SH   -> decimas de grado
├── mux SW(3)       -> temperatura o codigo crudo hacia los displays
├── bin_a_bcd + hex7seg x4 -> HEX3..HEX0
└── DAC R-2R (GPIO_0[16..23]), LEDR(0) actividad, LEDR(9) saturacion
```

## 4. Estructura de archivos

```
Laboratorio_II/
├── README.md                          (este archivo)
├── vhdl/
│   ├── gen_muestreo.vhd                generador de muestreo + perturbacion
│   ├── gen_muestreo_tb.vhd             banco de pruebas (verificado, pasa)
│   ├── adc0808_reader.vhd              lector del ADC0808 (de la Guia, cap. 12.2)
│   ├── adc0808_reader_tb.vhd           banco de pruebas con modelo de ADC0808 (verificado, pasa)
│   ├── FIR_Filter.vhd                  filtro FIR serie (de la Guia, cap. 12.5) — COEFICIENTES EN CERO
│   ├── FIR_Filter_tb.vhd               banco de pruebas contra in.txt/ref.txt de MATLAB
│   ├── bin_a_bcd.vhd                   binario a BCD (doble-dabble) — ADAPTACION, no viene de las fuentes
│   ├── hex7seg.vhd                     hex a 7 segmentos — ADAPTACION, no viene de las fuentes
│   └── top.vhd                         integracion completa
└── matlab/
    ├── exportar_coeficientes_S43.m     Num (Filter Designer) -> coeficientes.txt
    └── modelo_referencia_S43.m         genera in.txt / ref.txt para el testbench
```

## 5. Compilación y simulación (GHDL)

Todo este proyecto se verificó con **GHDL 4.1, `--std=08`**. Puedes usar los
mismos comandos, o el equivalente en ModelSim/QuestaSim (los testbenches no
usan nada específico de GHDL salvo el `report`/`assert`, estándar en VHDL).

```bash
cd vhdl

# 1) generador de muestreo (ya verificado: TODAS LAS COMPROBACIONES CORRECTAS)
ghdl -a --std=08 gen_muestreo.vhd gen_muestreo_tb.vhd
ghdl -e --std=08 gen_muestreo_tb
ghdl -r --std=08 gen_muestreo_tb

# 2) lector del ADC0808 (ya verificado: TODAS LAS COMPROBACIONES CORRECTAS)
ghdl -a --std=08 adc0808_reader.vhd adc0808_reader_tb.vhd
ghdl -e --std=08 adc0808_reader_tb
ghdl -r --std=08 adc0808_reader_tb --stop-time=50us

# 3) FIR (con coeficientes en cero, solo prueba la mecanica de archivos;
#    la comprobacion real es DESPUES de pegar los coeficientes reales)
ghdl -a --std=08 FIR_Filter.vhd FIR_Filter_tb.vhd
ghdl -e --std=08 FIR_Filter_tb
ghdl -r --std=08 FIR_Filter_tb        # necesita in.txt y ref.txt en la carpeta actual

# 4) integracion completa (solo elabora; top.vhd no tiene testbench propio,
#    se prueba en Quartus/ModelSim con el simulador de forma de onda, o
#    escribiendo un tb adicional que fije SW/KEY y observe las salidas)
ghdl -a --std=08 gen_muestreo.vhd adc0808_reader.vhd FIR_Filter.vhd bin_a_bcd.vhd hex7seg.vhd top.vhd
ghdl -e --std=08 top
```

## 6. Cómo pasar de MATLAB a VHDL (Etapas 6-9)

1. En el Filter Designer: **Lowpass | FIR Window | Blackman | Specify order**
   (empieza probando con el orden que te dé un número impar de coeficientes
   entre 23 y 33) **| Units: Hz | Fs = 800 | Fc = 112.5**.
2. Lee con el cursor la atenuación real en Fstop = 200 Hz. Si es menor de
   60 dB, sube el orden y repite. Anota el orden final: **N = FILTER_TAPS**.
3. `File > Export > Export to Workspace` (variable `Num` por defecto).
4. Ejecuta `matlab/exportar_coeficientes_S43.m` en la misma sesión de
   MATLAB. Genera `coeficientes.txt` con el bloque VHDL ya formateado (y
   verifica automáticamente la suma, el rango de 16 bits y el margen del
   acumulador, usando `MAXIN = 255` porque el ADC0808 es de 8 bits — este es
   el único número que cambia respecto del script de la Guía, que usa 1023
   para un conversor de 10 bits).
5. Pega el contenido de `coeficientes.txt` en `vhdl/FIR_Filter.vhd`,
   reemplazando el bloque marcado `-- PEGAR AQUI LOS COEFICIENTES...`.
   Cambia `FILTER_TAPS` (en `FIR_Filter.vhd` **y** en `FIR_Filter_tb.vhd`) al
   valor real que imprime el script.
6. Ejecuta `matlab/modelo_referencia_S43.m` (usa las variables `c` y `S` que
   dejó el paso 4). Genera `in.txt` y `ref.txt`; cópialos a `vhdl/`.
7. Simula `FIR_Filter_tb.vhd` (paso 3 de la sección 5). Debe reportar
   `diferencia maxima : 0 LSB` y `EL FILTRO COINCIDE EXACTAMENTE CON EL
   MODELO`. Cualquier diferencia indica un error real (ver la Tabla 12 de la
   Guía, "Errores Frecuentes", reproducida también en tu documento fuente).

## 7. Asignación de pines (Quartus)

Las fuentes no dan números físicos de pin de la FPGA (`PIN_xx`), solo
posiciones dentro de conectores ya conocidos (GPIO_0[n], CLOCK_50, KEY, SW,
HEX, LEDR). Usa el `.qsf` estándar de la tarjeta DE1 de Terasic para tu
FPGA (Cyclone II EP2C20), que ya trae la correspondencia `PIN_xx` correcta
para CLOCK_50, KEY, SW, HEX0-3, LEDR y el conector GPIO_0, y asigna:

| Señal en `top.vhd` | Recurso DE1 | Función |
|---|---|---|
| CLOCK_50 | CLOCK_50 | reloj de sistema, 50 MHz |
| KEY(0) | KEY[0] | reinicio general (activo en bajo) |
| SW(1 downto 0) | SW[1:0] | r del generador de perturbación |
| SW(2) | SW[2] | cruda ('0') o filtrada ('1') hacia el DAC |
| SW(3) | SW[3] | temperatura ('0') o código crudo ('1') en displays |
| GPIO_0(0) | GPIO_0[0] | pert, hacia el condensador de acoplo |
| GPIO_0(1) | GPIO_0[1] | latido, para medir Fs |
| GPIO_0(2) | GPIO_0[2] | adc_clk_o → CLK del ADC0808 |
| GPIO_0(3) | GPIO_0[3] | ale_o → ALE del ADC0808 |
| GPIO_0(4) | GPIO_0[4] | start_o → START del ADC0808 |
| GPIO_0(5) | GPIO_0[5] | oe_o → OE del ADC0808 |
| GPIO_0(6) | GPIO_0[6] | eoc_i ← EOC del ADC0808 (**adaptador 5V→3.3V**) |
| GPIO_0(14 downto 7) | GPIO_0[14:7] | data_i(7:0) ← D7..D0 del ADC0808 (**adaptador 5V→3.3V**) |
| GPIO_0(15) | GPIO_0[15] | libre |
| GPIO_0(23 downto 16) | GPIO_0[23:16] | dac_o(7:0) → red R-2R |
| HEX0..HEX3 | HEX0..HEX3 | displays de 7 segmentos |
| LEDR(0), LEDR(9) | LEDR[0], LEDR[9] | actividad de muestreo, saturación |

**ADAPTACIÓN AL ADC0808:** la Tabla 5 del Laboratorio deja "GPIO_0[2] en
adelante: número y función según el conversor elegido" para el ADC de
entrada, pensando en un conversor SPI de pocas líneas, y reserva ya
GPIO_0[16:23] para el DAC de salida. El ADC0808 necesita 16 líneas si se
cuentan también sus 3 pines de dirección de canal (ADD A/B/C), lo que
invadiría el bloque del DAC. Por eso, como este montaje usa un solo canal
(sensor), **las líneas ADD A/B/C del ADC0808 se atan directamente a GND en
la protoboard y no se conectan a la FPGA** (por eso `addr_o` queda `open` en
`top.vhd`). Con esto el ADC0808 solo necesita 13 líneas hacia la FPGA, que
caben exactamente entre GPIO_0[2] y GPIO_0[15], sin tocar el bloque del DAC.

**Compatibilidad eléctrica (obligatorio revisar antes de conectar):** el
ADC0808 en la Configuración B de la Tabla 1 se alimenta a 5 V, igual que el
LM358 (debe alimentarse también a 5 V, no a 3,3 V, para que su salida pueda
acercarse al fondo de escala del ADC0808). Los pines GPIO de la FPGA DE1
(Cyclone II) **no toleran 5 V**. Las líneas que van HACIA la FPGA desde el
ADC0808 (EOC y D7..D0) deben pasar por un adaptador de nivel — un 74HCT244
orientado hacia la FPGA, o divisores resistivos 1,8 kΩ/3,3 kΩ en cada línea,
como indica la Tabla 1 del Laboratorio. Las líneas que van DE la FPGA hacia
el ADC0808 (adc_clk_o, ale_o, start_o, oe_o) no necesitan adaptador: un nivel
alto de 3,3 V ya se reconoce como '1' en una entrada de 5 V del ADC0808.

## 8. Mediciones (Etapa 13)

1. Con el filtro aún no verificado, primero haz la **prueba intermedia**
   (Laboratorio, sección de comprobación): pon `SW(3)='1'` y confirma que el
   código crudo mostrado en los displays sube al calentar el sensor con el
   dedo, y que `LEDR(0)` destella con cada conversión.
2. Mide el **latido** (`GPIO_0[1]`) con el osciloscopio: debe dar 400 Hz
   (Fs/2 = 800/2). Si no da eso, el problema está en `gen_muestreo`/`DIV_FS`,
   no sigas adelante.
3. Con `SW(2)='0'` (cruda), observa en el DAC la señal contaminada con la
   perturbación de 200 Hz superpuesta a la temperatura.
4. Cambia a `SW(2)='1'` (filtrada) y confirma que la perturbación desaparece
   y la componente lenta de temperatura se conserva (con el retardo de grupo
   propio del filtro, (FILTER_TAPS−1)/2 muestras).
5. Recorre las cuatro posiciones de `SW(1:0)` (r = 4, 8, 16, 32) y confirma
   el patrón esperado: rechazo fuerte en r=4 (la posición de diseño, 200 Hz),
   cada vez menos rechazo a medida que la perturbación baja de frecuencia
   (100, 50, 25 Hz), acercándose a la banda de paso.
6. Contrasta la temperatura mostrada (`SW(3)='0'`) contra un termómetro de
   referencia.

## 9. Limitaciones conocidas / lo que debes verificar tú

- Los **coeficientes del FIR están en cero** (ver "Estado del proyecto").
- **K y SH son preliminares**: calculados con V_fs=5V nominal y ganancia=10
  nominal; verifica ambos valores con el multímetro antes de confiar en la
  temperatura mostrada.
- **`bin_a_bcd.vhd` y `hex7seg.vhd` son una adaptación mía**, no vienen de
  las fuentes (el encargo dice reutilizar los del Laboratorio 1, que no
  tengo). Si tu versión real usa otros puertos o genéricos, sustituye estos
  dos archivos por los tuyos; `top.vhd` solo necesita que
  `bin_a_bcd` entregue tres nibbles BCD (centenas, decenas, unidades) a
  partir de un binario de 10 bits.
- La interacción exacta entre `SW(2)` y `SW(3)` para el display en modo
  "código crudo" (¿el código crudo del ADC siempre, o el que esté activo
  según `SW(2)`?) no está explícita en las fuentes; aquí se implementó como
  "el que esté activo según SW(2)", coherente con la prueba intermedia de
  sección 2 punto 7. Ajusta `valor_mostrado_s` en `top.vhd` si tu docente
  espera otro comportamiento.
- No se ha simulado `top.vhd` con el `DIV_FS` real de 62500 (solo se
  comprobó que compila y elabora); antes de programar la FPGA, hazlo al
  menos una vez para tu propia tranquilidad.
- Los números de pin físico (`PIN_xx`) de Quartus no están asignados; usa el
  `.qsf` estándar de la DE1 como se indica en la sección 7.
