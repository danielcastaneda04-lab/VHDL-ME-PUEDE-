--------------------------------------------------------------------------------
-- gen_muestreo.vhd
-- Laboratorio 2 - Filtro FIR sobre FPGA con Perturbacion Coherente (UPTC Tunja)
-- Parametros individuales del grupo: S = 43
--
-- Genera, a partir de un unico contador, las tres senales que gobiernan la
-- practica:
--
--   fsclk  pulso de un ciclo de reloj a la frecuencia de muestreo Fs
--   latido conmuta en cada muestra; su frecuencia es Fs/2 y sirve para medir
--          Fs con el osciloscopio
--   pert   onda cuadrada que se inyecta como perturbacion, de frecuencia
--          f_n = Fs / r, con r seleccionable entre 4, 8, 16 y 32
--
-- Para S = 43:
--   Fs     = {320,400,500,800}[43 mod 4] = {320,400,500,800}[3] = 800 Hz
--   DIV_FS = 50 000 000 / 800 = 62 500              (entero y PAR, correcto)
--   f_n    = Fs / 4 = 200 Hz   (posicion de diseno, sel = "00")
--
-- Las dos propiedades de las que depende toda la practica son:
--
-- 1) La relacion Fs/f_n es un entero par EXACTO, porque ambas senales salen
--    del mismo contador. Solo asi los armonicos de la onda cuadrada de la
--    perturbacion se pliegan sobre multiplos de f_n y quedan dentro de la
--    banda de rechazo del filtro (ver README, seccion "Fundamento").
--
-- 2) Las transiciones de pert ocurren medio periodo de muestreo (DIV_FS/2
--    cuentas) antes del pulso fsclk, de modo que ningun instante de
--    muestreo cae sobre un flanco de la perturbacion. Sin este desfase el
--    rechazo cae de unos 45 dB a unos 5 dB.
--
-- DIV_FS = f_reloj / Fs y debe ser un numero PAR (condicion indispensable
-- para poder construir el desfase de medio periodo del punto 2).
--
-- Fuente: Laboratorio2_Filtro_FIR_Perturbacion_Coherente.pdf, seccion 5.3.
-- Codigo reproducido tal como lo entrega la guia; solo se cambio el valor
-- por defecto del generico DIV_FS de 125000 (ejemplo S=57, Fs=400Hz) a
-- 62500 (nuestro caso, S=43, Fs=800Hz).
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity gen_muestreo is
    generic (
        DIV_FS : positive := 62500  -- 50 MHz / 800 Hz  (S = 43); debe ser par
    );
    port (
        clk    : in  std_logic;
        rst    : in  std_logic;                     -- reinicio sincrono, activo en alto
        sel    : in  std_logic_vector(1 downto 0);  -- 00:r=4 01:r=8 10:r=16 11:r=32
        fsclk  : out std_logic;
        latido : out std_logic;
        pert   : out std_logic
    );
end entity gen_muestreo;

architecture rtl of gen_muestreo is

    -- numero de muestras que dura cada semiciclo de la perturbacion: r/2
    function semiciclo (s : std_logic_vector(1 downto 0)) return integer is
    begin
        case s is
            when "00"   => return 2;   -- r = 4
            when "01"   => return 4;   -- r = 8
            when "10"   => return 8;   -- r = 16
            when others => return 16;  -- r = 32
        end case;
    end function;

    signal cuenta   : integer range 0 to DIV_FS-1 := 0;
    signal n_semi   : integer range 0 to 15 := 0;
    signal sel_q    : std_logic_vector(1 downto 0) := "00";
    signal pulso    : std_logic := '0';
    signal latido_r : std_logic := '0';
    signal pert_r   : std_logic := '0';

begin

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                cuenta   <= 0;
                n_semi   <= 0;
                pulso    <= '0';
                latido_r <= '0';
                pert_r   <= '0';
                sel_q    <= sel;
            else
                sel_q <= sel;
                if cuenta = DIV_FS-1 then
                    cuenta   <= 0;
                    pulso    <= '1';           -- instante de muestreo
                    latido_r <= not latido_r;
                else
                    cuenta <= cuenta + 1;
                    pulso  <= '0';
                    -- medio periodo de muestreo antes del proximo pulso
                    if cuenta = DIV_FS/2 - 1 then
                        if sel /= sel_q then
                            n_semi <= 0;        -- reinicia al cambiar de posicion
                        elsif n_semi = semiciclo(sel) - 1 then
                            n_semi <= 0;
                            pert_r <= not pert_r;
                        else
                            n_semi <= n_semi + 1;
                        end if;
                    end if;
                end if;
            end if;
        end if;
    end process;

    fsclk  <= pulso;
    latido <= latido_r;
    pert   <= pert_r;

end architecture rtl;
