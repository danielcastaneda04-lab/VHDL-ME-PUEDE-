--------------------------------------------------------------------------------
-- gen_muestreo_tb.vhd
-- Banco de pruebas de gen_muestreo.vhd (Laboratorio 2, S = 43).
--
-- Verifica, para las cuatro posiciones del selector sel (r = 4, 8, 16, 32):
--   1) El periodo de fsclk es exactamente DIV_FS ciclos de reloj.
--   2) El semiperiodo de latido es exactamente DIV_FS ciclos (periodo = Fs/2).
--   3) El periodo de pert es exactamente r*DIV_FS ciclos (frecuencia Fs/r).
--   4) Cada transicion de pert ocurre exactamente DIV_FS/2 ciclos ANTES del
--      siguiente pulso de fsclk: el desfase de medio periodo de muestreo del
--      que depende todo el rechazo de la perturbacion (seccion 1.3 y 5.3 de
--      Laboratorio2_Filtro_FIR_Perturbacion_Coherente.pdf).
--
-- Para que la simulacion sea rapida se instancia el DUT con un DIV_FS mucho
-- mas pequeno que el real (62500 para S=43, Fs=800Hz): aqui se usa
-- DIV_FS_TB = 20 (par, como exige el diseno). La logica es identica; solo
-- cambia la escala de tiempo.
--
-- Ejecucion (GHDL):
--   ghdl -a --std=08 gen_muestreo.vhd gen_muestreo_tb.vhd
--   ghdl -e --std=08 gen_muestreo_tb
--   ghdl -r --std=08 gen_muestreo_tb --wave=gen_muestreo_tb.ghw
--
-- Que observar en ModelSim/QuestaSim/GTKWave (con el DIV_FS real = 62500):
--   - fsclk: pulsos de 1 ciclo de reloj, periodicos cada DIV_FS ciclos.
--   - latido: cuadrada que conmuta en cada pulso de fsclk (periodo doble
--     del de fsclk); su frecuencia medida en la FPGA debe dar Fs/2 = 400 Hz.
--   - pert: cuadrada cuya frecuencia cambia con sel; sus flancos NUNCA deben
--     coincidir con un pulso de fsclk, sino adelantarse siempre medio
--     periodo de muestreo (DIV_FS/2 ciclos).
--   Si "errores" queda en 0 al final del log, las cuatro propiedades quedan
--   demostradas para las cuatro posiciones del selector.
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity gen_muestreo_tb is
end entity gen_muestreo_tb;

architecture sim of gen_muestreo_tb is

    constant DIV_FS_TB : positive := 20;   -- par; reducido SOLO para simular rapido
    constant T_CLK      : time := 20 ns;   -- reloj de 50 MHz

    signal clk    : std_logic := '0';
    signal rst    : std_logic := '1';
    signal sel    : std_logic_vector(1 downto 0) := "00";
    signal fsclk  : std_logic;
    signal latido : std_logic;
    signal pert   : std_logic;
    signal fin    : boolean := false;

begin

    clk <= not clk after T_CLK/2 when not fin else '0';

    uut : entity work.gen_muestreo
        generic map (
            DIV_FS => DIV_FS_TB
        )
        port map (
            clk    => clk,
            rst    => rst,
            sel    => sel,
            fsclk  => fsclk,
            latido => latido,
            pert   => pert
        );

    prueba : process
        variable errores : integer := 0;
        variable t1, t2  : time;

        procedure check(constant cond : boolean; constant msg : string) is
        begin
            if not cond then
                errores := errores + 1;
                report "FALLO: " & msg severity warning;
            else
                report "OK: " & msg severity note;
            end if;
        end procedure;

        procedure medir_fsclk is
        begin
            wait until rising_edge(fsclk);
            t1 := now;
            wait until rising_edge(fsclk);
            t2 := now;
            check((t2 - t1) = DIV_FS_TB * T_CLK, "periodo de fsclk = DIV_FS ciclos");
        end procedure;

        procedure medir_latido is
        begin
            wait until (fsclk'event and fsclk = '1');
            wait until (latido'event);
            t1 := now;
            wait until (latido'event);
            t2 := now;
            check((t2 - t1) = DIV_FS_TB * T_CLK,
                  "semiperiodo de latido = DIV_FS ciclos (periodo = Fs/2)");
        end procedure;

        procedure medir_pert(constant r : integer) is
        begin
            wait until (pert'event and pert = '1');
            t1 := now;
            wait until (pert'event and pert = '1');
            t2 := now;
            check((t2 - t1) = r * DIV_FS_TB * T_CLK, "periodo de pert = r * DIV_FS ciclos");
        end procedure;

        procedure medir_fase is
        begin
            wait until pert'event;
            t1 := now;
            wait until (fsclk'event and fsclk = '1');
            t2 := now;
            check((t2 - t1) = (DIV_FS_TB/2) * T_CLK,
                  "desfase pert->fsclk = medio periodo de muestreo (DIV_FS/2 ciclos)");
        end procedure;

    begin
        rst <= '1';
        wait for 5 * T_CLK;
        rst <= '0';
        wait until (fsclk'event and fsclk = '1');   -- deja pasar el primer pulso tras el reset

        report "=== sel = 00  (r = 4,  f_n = Fs/4  = 200 Hz para S=43, posicion de diseno) ===" severity note;
        sel <= "00";
        wait until (fsclk'event and fsclk = '1');
        medir_fsclk;
        medir_latido;
        medir_pert(4);
        medir_fase;

        report "=== sel = 01  (r = 8,  f_n = Fs/8  = 100 Hz) ===" severity note;
        sel <= "01";
        wait for 2 * DIV_FS_TB * T_CLK;   -- deja estabilizar tras el cambio de sel
        medir_pert(8);
        medir_fase;

        report "=== sel = 10  (r = 16, f_n = Fs/16 =  50 Hz) ===" severity note;
        sel <= "10";
        wait for 2 * DIV_FS_TB * T_CLK;
        medir_pert(16);
        medir_fase;

        report "=== sel = 11  (r = 32, f_n = Fs/32 =  25 Hz) ===" severity note;
        sel <= "11";
        wait for 2 * DIV_FS_TB * T_CLK;
        medir_pert(32);
        medir_fase;

        report "muestras de fsclk / latido / pert comprobadas para las cuatro posiciones" severity note;
        if errores = 0 then
            report "=== gen_muestreo_tb: TODAS LAS COMPROBACIONES CORRECTAS ===" severity note;
        else
            report "=== gen_muestreo_tb: " & integer'image(errores) & " FALLO(S) DETECTADO(S) ===" severity error;
        end if;

        fin <= true;
        wait;
    end process prueba;

end architecture sim;
