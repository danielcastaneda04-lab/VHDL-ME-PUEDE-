--------------------------------------------------------------------------------
-- hex7seg.vhd
-- Decodificador de un digito hexadecimal (0 a F) a siete segmentos, activo
-- en bajo (un '0' enciende el segmento), que es la convencion de los
-- displays HEX de la tarjeta DE1 (Terasic, manual capitulo 4).
--
-- ADAPTACION -- NO VIENE DE LAS FUENTES: igual que bin_a_bcd.vhd, este
-- modulo deberia reutilizarse del Laboratorio 1 segun el encargo, pero no
-- esta entre los documentos que me diste. Esta es la tabla estandar de
-- conversion hex->7 segmentos (la misma que usan los tutoriales de Terasic
-- para la DE1); si tu version del Laboratorio 1 usa otra polaridad o otros
-- puertos, sustituye este archivo por el tuyo.
--
-- Al decodificar el propio digito hexadecimal 0xC se obtiene la letra "C"
-- que exige el punto 4 de la seccion 5.9 del Laboratorio ("la letra C en
-- HEX3"): basta con conectar HEX3 a un hex7seg cuya entrada este fijada en
-- "1100" (ver top.vhd), sin necesidad de un decodificador aparte para la
-- letra.
--
-- segments_o(6 downto 0) = g f e d c b a  (orden habitual HEXn[6:0] de la DE1)
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity hex7seg is
    port (
        hex_i      : in  std_logic_vector(3 downto 0);
        segments_o : out std_logic_vector(6 downto 0)
    );
end entity hex7seg;

architecture rtl of hex7seg is
begin
    process (hex_i)
    begin
        case hex_i is
            when "0000" => segments_o <= "1000000";  -- 0
            when "0001" => segments_o <= "1111001";  -- 1
            when "0010" => segments_o <= "0100100";  -- 2
            when "0011" => segments_o <= "0110000";  -- 3
            when "0100" => segments_o <= "0011001";  -- 4
            when "0101" => segments_o <= "0010010";  -- 5
            when "0110" => segments_o <= "0000010";  -- 6
            when "0111" => segments_o <= "1111000";  -- 7
            when "1000" => segments_o <= "0000000";  -- 8
            when "1001" => segments_o <= "0010000";  -- 9
            when "1010" => segments_o <= "0001000";  -- A
            when "1011" => segments_o <= "0000011";  -- b
            when "1100" => segments_o <= "1000110";  -- C  (usado en HEX3 para la letra "C")
            when "1101" => segments_o <= "0100001";  -- d
            when "1110" => segments_o <= "0000110";  -- E
            when "1111" => segments_o <= "0001110";  -- F
            when others => segments_o <= "1111111";  -- apagado
        end case;
    end process;
end architecture rtl;
