----------------------------------------------------------------------------------
-- FIR_Filter.vhd
-- Filtro FIR de forma directa con implementacion serie: un unico multiplicador
-- recorre los FILTER_TAPS coeficientes, uno por ciclo de reloj.
--
-- Fuente: Guia_FIR_FilterDesigner_v5.pdf, seccion 12.5 (a su vez basado en el
-- codigo publicado por Dimitar Marinov en VHDLwhiz, parte 2, con las cuatro
-- correcciones que describe la guia). Codigo reproducido tal cual; lo unico
-- que cambia respecto de la guia es el bloque de coeficientes (ver mas abajo).
--
-- Salida: y[n] = ( suma de c_k * x[n-1-k] ) / 2**(INPUT_WIDTH+COEFF_WIDTH-OUTPUT_WIDTH-1)
-- Requisito de temporizacion: entre dos pulsos de fsclk debe haber al menos
-- FILTER_TAPS+2 ciclos de clk. Con Fs=800 Hz (S=43), Ts=1,25 ms = 62 500
-- ciclos de reloj de 50 MHz frente a los ~29 que necesita el filtro (para
-- FILTER_TAPS=27): margen de mas de 2000 veces, muy por encima del minimo.
--
-- =====================================================================
-- COEFICIENTES: ESTE ARCHIVO TRAE UN RELLENO DE CEROS, NO UN FILTRO REAL
-- =====================================================================
-- FILTER_TAPS = 27 es solo un valor de partida (numero impar, dentro del
-- rango de 23 a 33 coeficientes que anuncia el Laboratorio para cualquier
-- grupo). El numero real para S=43 sale de iterar en el Filter Designer de
-- MATLAB (Lowpass, FIR Window, Blackman, Fs=800 Hz, Fc=112,5 Hz) subiendo el
-- orden hasta que la atenuacion leida en el cursor sobre Fstop=200 Hz sea de
-- al menos 60 dB (Tabla 7 del Laboratorio). Con los coeficientes en ceros la
-- salida es siempre cero: es intencional, para que el proyecto compile y se
-- pueda simular/integrar ya mismo, pero AUN NO ES EL FILTRO DE LA PRACTICA.
--
-- Pasos para completarlo (ver tambien matlab/exportar_coeficientes_S43.m):
--   1) Disena el filtro en el Filter Designer y haz Export > Num a Workspace.
--   2) Ejecuta exportar_coeficientes_S43.m; genera coeficientes.txt con el
--      numero real de coeficientes y el bloque coeff_s ya formateado.
--   3) Cambia FILTER_TAPS abajo al numero real de coeficientes (debe ser
--      impar; con la ventana Blackman aqui suele salir entre 23 y 33).
--   4) Pega el contenido de coeficientes.txt sustituyendo el bloque
--      "-- PEGAR AQUI LOS COEFICIENTES GENERADOS EN MATLAB" de mas abajo.
-- =====================================================================
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity FIR_Filter is
    generic(
        FILTER_TAPS  : integer := 27;  -- PLACEHOLDER: ajustar al orden real para S=43 (23 a 33, impar)
        INPUT_WIDTH  : integer range 8 to 32 := 16;
        COEFF_WIDTH  : integer range 8 to 32 := 16;
        OUTPUT_WIDTH : integer range 8 to 32 := 16
    );
    Port (
        clk    : in  STD_LOGIC;
        fsclk  : in  STD_LOGIC;
        data_i : in  STD_LOGIC_Vector(INPUT_WIDTH-1 downto 0);
        data_o : out STD_LOGIC_Vector(OUTPUT_WIDTH-1 downto 0)
    );
end FIR_Filter;

architecture Behavioral of FIR_Filter is

    type input_registers is array(0 to FILTER_TAPS-1) of signed(INPUT_WIDTH-1 downto 0);
    signal delay_line_s : input_registers := (others => (others => '0'));

    type coefficients is array (0 to FILTER_TAPS-1) of signed(COEFF_WIDTH-1 downto 0);
    signal coeff_s : coefficients := (
        -- =====================================================================
        -- PEGAR AQUI LOS COEFICIENTES GENERADOS EN MATLAB (S = 43)
        -- Deben ser EXACTAMENTE FILTER_TAPS valores; el ultimo termina en );
        -- sin coma. Salida de matlab/exportar_coeficientes_S43.m (coeficientes.txt).
        -- =====================================================================
        x"0000", x"0000", x"0000", x"0000", x"0000", x"0000",
        x"0000", x"0000", x"0000", x"0000", x"0000", x"0000",
        x"0000", x"0000", x"0000", x"0000", x"0000", x"0000",
        x"0000", x"0000", x"0000", x"0000", x"0000", x"0000",
        x"0000", x"0000", x"0000");

    signal fs_ff1, fs_ff2, fs_ff3 : std_logic := '0';  -- sincronizador de tres etapas

    type state_machine is (idle_st, active_st);
    signal state : state_machine := idle_st;

    signal counter     : integer range 0 to FILTER_TAPS-1 := FILTER_TAPS-1;
    signal output      : signed(INPUT_WIDTH+COEFF_WIDTH-1 downto 0) := (others => '0');
    signal accumulator : signed(INPUT_WIDTH+COEFF_WIDTH-1 downto 0) := (others => '0');

begin

    data_o <= std_logic_vector(
        output(INPUT_WIDTH+COEFF_WIDTH-2 downto INPUT_WIDTH+COEFF_WIDTH-OUTPUT_WIDTH-1));

    process(clk)
        variable sum_v : signed(INPUT_WIDTH+COEFF_WIDTH-1 downto 0) := (others => '0');
    begin
        if rising_edge(clk) then
            fs_ff1 <= fsclk; fs_ff2 <= fs_ff1; fs_ff3 <= fs_ff2;
            case state is
                when idle_st =>
                    if fs_ff2 = '1' and fs_ff3 = '0' then
                        state <= active_st;
                    end if;
                when active_st =>
                    if counter > 0 then
                        counter <= counter - 1;
                    else
                        counter <= FILTER_TAPS-1;
                        state   <= idle_st;
                    end if;
                    if counter > 0 then
                        delay_line_s(counter) <= delay_line_s(counter-1);
                    else
                        delay_line_s(counter) <= signed(data_i);
                    end if;
                    if counter > 0 then
                        sum_v := delay_line_s(counter) * coeff_s(counter);
                        accumulator <= accumulator + sum_v;
                    else
                        accumulator <= (others => '0');
                        sum_v := delay_line_s(counter) * coeff_s(counter);
                        output <= accumulator + sum_v;
                    end if;
            end case;
        end if;
    end process;

end Behavioral;
