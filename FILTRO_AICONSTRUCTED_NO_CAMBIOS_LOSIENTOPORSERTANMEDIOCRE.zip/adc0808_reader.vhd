--------------------------------------------------------------------------------
-- adc0808_reader.vhd
-- Gobierna un ADC0808 / ADC0809 desde la FPGA y entrega la muestra al filtro FIR.
--
-- Fuente: Guia_FIR_FilterDesigner_v5.pdf, seccion 12.2. Codigo reproducido tal
-- cual lo entrega la guia (ya esta escrito de forma generica para ADC0808, no
-- es una adaptacion de un modulo SPI). Solo se cambio el generico CLK_DIV por
-- defecto para nuestro caso:
--
--   ADAPTACION AL ADC0808 (S = 43): la guia trae CLK_DIV = 250 (f_ADC = 100 kHz)
--   como ejemplo generico. Aqui se usa CLK_DIV = 125 (f_ADC = 200 kHz) porque
--   nuestro periodo de muestreo es mas corto que el del ejemplo (Fs = 800 Hz,
--   Ts = 1,25 ms) y conviene mas margen entre el fin de una conversion y el
--   siguiente disparo:
--     f_ADC = f_reloj / (2*CLK_DIV) = 50 000 000 / (2*125) = 200 kHz
--     (dentro de la hoja de datos: 10 kHz <= f_ADC <= 1,28 MHz)
--     secuencia completa ~= 68 ciclos de adc_clk = 68/200000 = 340 us
--     margen frente al periodo de muestreo: 1250 us / 340 us =~ 3,7x
--   (con CLK_DIV=250 el margen habria sido de solo 1,8x; sigue siendo valido,
--   pero mas ajustado).
--
-- Reloj de conversion: f_ADC = f_reloj / (2 * CLK_DIV)
-- (hacen falta DOS conmutaciones para completar un periodo)
-- La conversion propiamente dicha consume 64 ciclos del reloj del conversor,
-- pero la secuencia completa consume unos 68 porque hay que sumarle los pulsos
-- de ALE y START y la deteccion del fin de conversion.
--
-- La hoja de datos exige 10 kHz <= f_ADC <= 1,28 MHz.
--
-- Secuencia: al recibir un pulso en inicio_i se pulsa ALE para fijar el canal, se
-- pulsa START, se espera a que EOC baje (la conversion ha comenzado), se espera a
-- que EOC vuelva a subir (ha terminado) y solo entonces se activa OE y se lee.
--
-- RECOMENDACION DE LA GUIA (la seguimos): conectar inicio_i a fsclk, la salida
-- del divisor de muestreo (gen_muestreo.vhd en nuestro caso). Asi Fs = 800 Hz
-- queda fijada exactamente por la FPGA y no depende de la sobrecarga de la
-- maquina de estados. Si se ata inicio_i a '1' el modulo convierte libremente
-- y entonces Fs =~ f_ADC / 68, que NO seria la Fs de diseno.
--
-- IMPORTANTE (compatibilidad electrica, seccion 18 del encargo): el ADC0808 se
-- alimenta a 5 V y sus salidas (EOC, D0-D7) son de 5 V. Los pines de la FPGA
-- DE1 (Cyclone II, 3.3 V) NO toleran 5 V directos. eoc_i y data_i deben pasar
-- por un adaptador de nivel 5V->3.3V (74HCT244 orientado hacia la FPGA, o
-- divisores resistivos 1.8k/3.3k en cada linea, tal como indica la Tabla 1 de
-- Laboratorio2_Filtro_FIR_Perturbacion_Coherente.pdf para la Configuracion B).
-- Las salidas de la FPGA hacia el ADC0808 (adc_clk_o, ale_o, start_o, oe_o,
-- addr_o) SI son compatibles: un nivel alto de 3.3V ya se reconoce como '1'
-- logico en la entrada de un CI de 5V (VIH tipico del ADC0808 =~ 2V).
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity adc0808_reader is
    generic (
        CLK_DIV    : positive := 125;  -- f_ADC = 50 MHz/(2*125) = 200 kHz (S=43)
        CANAL      : integer range 0 to 7 := 0;
        DATA_WIDTH : positive := 16    -- ancho de la palabra hacia el FIR
    );
    port (
        clk : in std_logic;
        rst : in std_logic;
        -- interfaz con el ADC0808
        adc_clk_o : out std_logic;
        ale_o     : out std_logic;
        start_o   : out std_logic;
        oe_o      : out std_logic;
        eoc_i     : in  std_logic;
        inicio_i  : in  std_logic;                     -- pulso que dispara una conversion
        addr_o    : out std_logic_vector(2 downto 0);
        data_i    : in  std_logic_vector(7 downto 0);
        -- salida hacia el filtro FIR
        data_o  : out std_logic_vector(DATA_WIDTH-1 downto 0);
        valid_o : out std_logic                        -- pulso de un ciclo
    );
end entity adc0808_reader;

architecture rtl of adc0808_reader is
    type t_estado is (S_REPOSO, S_ALE, S_START, S_ESPERA_BAJA, S_ESPERA_SUBE, S_LEE);
    signal estado  : t_estado := S_REPOSO;
    signal clk_cnt : integer range 0 to CLK_DIV-1 := 0;
    signal adc_clk : std_logic := '0';
    signal tick    : std_logic := '0';                 -- pulso al subir adc_clk
    signal cnt     : integer range 0 to 7 := 0;
    signal eoc_1, eoc_2 : std_logic := '1';             -- sincronizador de EOC
begin

    addr_o    <= std_logic_vector(to_unsigned(CANAL, 3));
    adc_clk_o <= adc_clk;

    -- generador del reloj del conversor -----------------------------------
    reloj : process (clk)
    begin
        if rising_edge(clk) then
            tick <= '0';
            if rst = '1' then
                clk_cnt <= 0; adc_clk <= '0';
            elsif clk_cnt = CLK_DIV-1 then
                clk_cnt <= 0;
                adc_clk <= not adc_clk;
                tick    <= not adc_clk;                -- alto solo al subir adc_clk
            else
                clk_cnt <= clk_cnt + 1;
            end if;
        end if;
    end process;

    -- maquina de estados ---------------------------------------------------
    fsm : process (clk)
    begin
        if rising_edge(clk) then
            eoc_1 <= eoc_i; eoc_2 <= eoc_1;             -- sincroniza la entrada asincrona
            valid_o <= '0';
            if rst = '1' then
                estado <= S_REPOSO; cnt <= 0;
                ale_o <= '0'; start_o <= '0'; oe_o <= '0';
                data_o <= (others => '0');
            else
                case estado is
                    when S_REPOSO =>
                        ale_o <= '0'; start_o <= '0'; oe_o <= '0';
                        if inicio_i = '1' then
                            cnt <= 0; estado <= S_ALE;
                        end if;
                    when S_ALE =>
                        ale_o <= '1'; start_o <= '0'; oe_o <= '0';
                        if tick = '1' then
                            if cnt = 1 then
                                cnt <= 0; estado <= S_START;
                            else
                                cnt <= cnt + 1;
                            end if;
                        end if;
                    when S_START =>
                        ale_o <= '0'; start_o <= '1';
                        if tick = '1' then
                            if cnt = 1 then
                                start_o <= '0'; cnt <= 0; estado <= S_ESPERA_BAJA;
                            else
                                cnt <= cnt + 1;
                            end if;
                        end if;
                    when S_ESPERA_BAJA =>                -- la conversion ha comenzado
                        start_o <= '0';
                        if eoc_2 = '0' then
                            estado <= S_ESPERA_SUBE;
                        end if;
                    when S_ESPERA_SUBE =>                 -- la conversion ha terminado
                        if eoc_2 = '1' then
                            oe_o <= '1';
                            cnt <= 0;
                            estado <= S_LEE;
                        end if;
                    when S_LEE =>
                        oe_o <= '1';
                        if tick = '1' then                -- deja tiempo a la salida triestado
                            data_o  <= std_logic_vector(resize(unsigned(data_i), DATA_WIDTH));
                            valid_o <= '1';
                            oe_o    <= '0';
                            estado  <= S_REPOSO;
                        end if;
                end case;
            end if;
        end if;
    end process;

end architecture rtl;
