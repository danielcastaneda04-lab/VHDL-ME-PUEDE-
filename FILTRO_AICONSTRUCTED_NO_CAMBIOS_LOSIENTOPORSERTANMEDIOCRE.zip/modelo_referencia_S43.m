% ---------------------------------------------------------------------
% modelo_referencia_S43.m
% Modelo entero del filtro, con la misma aritmetica que el VHDL.
% Genera los vectores que consume FIR_Filter_tb.vhd (in.txt, ref.txt).
% Ejecutar despues de exportar_coeficientes_S43.m (usa las variables c y S).
%
% Fuente: Guia_FIR_FilterDesigner_v5.pdf, seccion 10 (modelo_referencia.m).
% Adaptado a S = 43:
%   - Fs = 800 Hz (no 400) y Fruido = 200 Hz (no 100), los valores propios
%     calculados en la Etapa 1.
%   - La senal de prueba se reescala porque nuestro conversor es de 8 bits
%     (codigos 0-255) y no de 10 bits (codigos 0-1023) como en el ejemplo
%     de la guia: la linea base pasa de 500 a 125 (mitad de escala de 8
%     bits) y las dos amplitudes se reducen en la misma proporcion
%     (255/1023 =~ 0,25) para que la señal simulada quepa siempre en el
%     rango 0-255 del ADC0808, igual que le pasaria a la señal real.
%   - Se usan 1200 muestras en vez de 600 para conservar la misma duracion
%     de 1,5 s que en el ejemplo de la guia, ya que Fs se duplico.
% ---------------------------------------------------------------------
Fs = 800;          % frecuencia de muestreo real, en Hz (S = 43)
Fruido = 200;       % frecuencia de la perturbacion a eliminar, en Hz (S = 43: f_n = Fs/4)
N = numel(c);
Q = log2(S);
n = 0:1199;                     % 1200 muestras -> 1200/800 = 1,5 s (misma duracion que el ejemplo de la guia)
t = n / Fs;

% senal de prueba: componente lenta util (escalon suavizado) mas
% perturbacion a eliminar, todo dentro del rango 0-255 del ADC0808
x = round( 125 + 60./(1+exp(-(t-1.10)/0.05)) + 30*sin(2*pi*Fruido*t + 0.7) );
x = min(max(x, 0), 255);   % seguridad: satura al rango real del ADC0808 si algun pico se sale

% filtrado con aritmetica entera identica a la del VHDL
xe = [zeros(1,N) x];
y = zeros(1,numel(x));
for k = 1:numel(x)
    acc = sum( int64(c) .* int64(fliplr(xe(k : k+N-1))) );
    y(k) = double( bitshift(acc, -Q) );
end

fid = fopen('in.txt','w');  fprintf(fid,'%d\n',x); fclose(fid);
fid = fopen('ref.txt','w'); fprintf(fid,'%d\n',y); fclose(fid);

fprintf('Vectores generados: %d muestras\n', numel(x));
fprintf('Rizado a la entrada: %d codigos\n', max(x(120:760))-min(x(120:760)));
fprintf('Rizado a la salida : %d codigos\n', max(y(120:760))-min(y(120:760)));
disp('Copia in.txt y ref.txt a la carpeta vhdl/ antes de ejecutar FIR_Filter_tb.vhd.');
