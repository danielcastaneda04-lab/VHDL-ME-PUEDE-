--------------------------------------------------------------------------------
-- top.vhd
-- Integracion completa del Laboratorio 2 (S = 43, ADC0808 de 8 bits, DAC R-2R
-- de 8 bits) sobre la tarjeta DE1.
--
--   FPGA
--   |
--   +-- gen_muestreo   -> fsclk (dispara al ADC), latido (GPIO_0[1]),
--   |                     pert (GPIO_0[0], hacia el condensador de acoplo)
--   +-- adc0808_reader -> gobierna el ADC0808 (GPIO_0[2..14]) y entrega
--   |                     adc_data_s (16 bits, 8 utiles) cuando valid_s='1'
--   +-- FIR_Filter     -> filtra adc_data_s, disparado por valid_s;
--   |                     entrega fir_data_s (16 bits, 8 utiles)
--   +-- muxes SW(2)/SW(3), escalado a decimas de grado (K, SH)
--   +-- bin_a_bcd + hex7seg x4 -> HEX3..HEX0
--   +-- DAC R-2R (GPIO_0[16..23])
--   +-- LEDR(0) (actividad de muestreo), LEDR(9) (saturacion)
--
-- Asignacion de recursos DE1 (Tabla 5 de Laboratorio2_Filtro_FIR_
-- Perturbacion_Coherente.pdf, con la ADAPTACION AL ADC0808 explicada en el
-- README para GPIO_0[2..15], que la guia deja abiertos a "segun el
-- conversor elegido"):
--
--   CLOCK_50      reloj de sistema, 50 MHz
--   KEY(0)        reinicio general (activo en bajo; se invierte aqui)
--   SW(1 downto 0)  r del generador de perturbacion (00:4 01:8 10:16 11:32)
--   SW(2)           derivacion del filtro: '0' cruda al DAC, '1' filtrada
--   SW(3)           visualizacion: '0' temperatura, '1' codigo crudo (decimal)
--   GPIO_0(0)       pert          (hacia el condensador de acoplo)
--   GPIO_0(1)       latido        (para medir Fs con el osciloscopio)
--   GPIO_0(2)       adc_clk_o     (reloj de conversion del ADC0808, 200 kHz)
--   GPIO_0(3)       ale_o
--   GPIO_0(4)       start_o
--   GPIO_0(5)       oe_o
--   GPIO_0(6)       eoc_i         (entrada; ADAPTACION DE NIVEL 5V->3.3V)
--   GPIO_0(14..7)   data_i(7..0)  (bus de datos D7..D0; ADAPTACION 5V->3.3V)
--   GPIO_0(15)      libre
--   GPIO_0(23..16)  dac_o(7..0)   (hacia la red R-2R)
--   HEX3..HEX0      letra "C" y temperatura (o codigo crudo) a 7 segmentos
--   LEDR(0)         actividad de muestreo (destella con cada conversion)
--   LEDR(9)         saturacion (codigo en 0x00 o 0xFF)
--
-- Las lineas ADD A/B/C del ADC0808 NO se conectan a la FPGA: como solo se usa
-- un canal (CANAL=0 en adc0808_reader), se atan directamente a GND en la
-- protoboard. Esto es lo que libera los pines necesarios para que las 13
-- lineas del ADC0808 (adc_clk, ale, start, oe, eoc, 8 bits de datos) quepan
-- entre GPIO_0(2) y GPIO_0(15), sin invadir el bloque GPIO_0(16..23) que la
-- Tabla 5 reserva para el DAC de salida. Ver README.md, seccion "Pines".
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity top is
    port (
        CLOCK_50 : in    std_logic;
        KEY      : in    std_logic_vector(0 downto 0);
        SW       : in    std_logic_vector(3 downto 0);
        GPIO_0   : inout std_logic_vector(23 downto 0);
        HEX0     : out   std_logic_vector(6 downto 0);
        HEX1     : out   std_logic_vector(6 downto 0);
        HEX2     : out   std_logic_vector(6 downto 0);
        HEX3     : out   std_logic_vector(6 downto 0);
        LEDR     : out   std_logic_vector(9 downto 0)
    );
end entity top;

architecture rtl of top is

    -- constantes de S = 43 -------------------------------------------------
    constant DIV_FS_C  : positive := 62500;  -- 50 MHz / 800 Hz
    constant CLK_DIV_C  : positive := 125;    -- f_ADC = 200 kHz
    constant FILTER_TAPS_C : integer := 27;   -- PLACEHOLDER, ver FIR_Filter.vhd

    -- ADAPTACION: constantes K y SH preliminares (Etapa 1), calculadas para
    -- ADC0808 (W=8 bits) con fondo de escala V_fs=5V (Tabla 1, Configuracion
    -- B). Deben recalcularse si la ganancia medida difiere de 10 o si el
    -- fondo de escala real del ADC0808 (VREF+/VREF-) no es 5V exactos.
    constant K_C  : natural := 2209;
    constant SH_C : natural := 10;

    signal rst : std_logic;

    -- gen_muestreo
    signal fsclk_s, latido_s, pert_s : std_logic;

    -- adc0808_reader
    signal adc_data_s  : std_logic_vector(15 downto 0);
    signal adc_valid_s : std_logic;

    -- FIR
    signal fir_data_s : std_logic_vector(15 downto 0);

    -- seleccion SW(2): muestra cruda o filtrada (misma senal para DAC,
    -- indicador de saturacion y, si SW(3)='1', tambien para el display)
    signal activo_8b : std_logic_vector(7 downto 0);

    -- escalado a decimas de grado: T_decimas = (activo_8b * K_C) >> SH_C
    signal producto_s   : unsigned(19 downto 0);
    signal t_decimas_s  : unsigned(9 downto 0);

    -- valor que se muestra en los displays: temperatura o codigo crudo
    signal valor_mostrado_s : std_logic_vector(9 downto 0);

    signal bcd_centenas, bcd_decenas, bcd_unidades : std_logic_vector(3 downto 0);

begin

    rst <= not KEY(0);

    -- 1) generador de muestreo y perturbacion -------------------------------
    u_gen_muestreo : entity work.gen_muestreo
        generic map (
            DIV_FS => DIV_FS_C
        )
        port map (
            clk    => CLOCK_50,
            rst    => rst,
            sel    => SW(1 downto 0),
            fsclk  => fsclk_s,
            latido => latido_s,
            pert   => pert_s
        );

    GPIO_0(0) <= pert_s;
    GPIO_0(1) <= latido_s;

    -- 2) lector del ADC0808 --------------------------------------------------
    u_adc0808 : entity work.adc0808_reader
        generic map (
            CLK_DIV    => CLK_DIV_C,
            CANAL      => 0,
            DATA_WIDTH => 16
        )
        port map (
            clk       => CLOCK_50,
            rst       => rst,
            adc_clk_o => GPIO_0(2),
            ale_o     => GPIO_0(3),
            start_o   => GPIO_0(4),
            oe_o      => GPIO_0(5),
            eoc_i     => GPIO_0(6),
            inicio_i  => fsclk_s,
            addr_o    => open,          -- ADD A/B/C atados a GND en la protoboard
            data_i    => GPIO_0(14 downto 7),
            data_o    => adc_data_s,
            valid_o   => adc_valid_s
        );

    -- GPIO_0(15) queda libre (no se conecta)

    -- 3) filtro FIR ------------------------------------------------------------
    u_fir : entity work.FIR_Filter
        generic map (
            FILTER_TAPS  => FILTER_TAPS_C,
            INPUT_WIDTH  => 16,
            COEFF_WIDTH  => 16,
            OUTPUT_WIDTH => 16
        )
        port map (
            clk    => CLOCK_50,
            fsclk  => adc_valid_s,   -- se dispara en cuanto el ADC entrega el dato
            data_i => adc_data_s,
            data_o => fir_data_s
        );

    -- 4) seleccion cruda/filtrada (SW(2)) hacia el DAC y el indicador -----------
    activo_8b <= adc_data_s(7 downto 0) when SW(2) = '0' else fir_data_s(7 downto 0);

    -- rango util W=D=8 bits (ADC0808 de 8 bits, DAC R-2R de 8 bits):
    -- dac <= data_o(W-1 downto W-D) = data_o(7 downto 0), sin desplazar
    GPIO_0(23 downto 16) <= activo_8b;

    -- 5) escalado a decimas de grado: T_decimas = (codigo * K) >> SH -----------
    producto_s  <= unsigned(activo_8b) * to_unsigned(K_C, 12);
    t_decimas_s <= producto_s(19 downto 10);

    -- 6) seleccion de visualizacion (SW(3)) -------------------------------------
    valor_mostrado_s <= std_logic_vector(t_decimas_s) when SW(3) = '0'
                    else "00" & activo_8b;  -- codigo crudo, extendido a 10 bits

    u_bcd : entity work.bin_a_bcd
        generic map (
            INPUT_WIDTH => 10
        )
        port map (
            bin_i      => valor_mostrado_s,
            centenas_o => bcd_centenas,
            decenas_o  => bcd_decenas,
            unidades_o => bcd_unidades
        );

    u_hex0 : entity work.hex7seg port map (hex_i => bcd_unidades, segments_o => HEX0);
    u_hex1 : entity work.hex7seg port map (hex_i => bcd_decenas,  segments_o => HEX1);
    u_hex2 : entity work.hex7seg port map (hex_i => bcd_centenas, segments_o => HEX2);
    u_hex3 : entity work.hex7seg port map (hex_i => "1100",       segments_o => HEX3);  -- letra "C" fija

    -- 7) indicadores ------------------------------------------------------------
    LEDR(0) <= adc_valid_s;  -- destella (a nivel logico) con cada conversion completada
    LEDR(8 downto 1) <= (others => '0');
    LEDR(9) <= '1' when (activo_8b = x"00" or activo_8b = x"FF") else '0';

end architecture rtl;
