--------------------------------------------------------------------------------
-- adc0808_reader_tb.vhd
-- Banco de pruebas de adc0808_reader.vhd con un modelo de comportamiento
-- simplificado del ADC0808 (no existe un ADC0808 real en simulacion; la
-- guia advierte que este modulo "se verifico contra un modelo de
-- comportamiento del conversor" -- este es ese modelo, escrito para nuestro
-- caso).
--
-- El modelo:
--   - Espera un pulso (flanco de subida) en start_o, que es el instante en
--     que un ADC0808 real inicia la conversion.
--   - Tras un retardo (tiempo de adquisicion), baja EOC.
--   - Tras otro retardo (tiempo de conversion), sube EOC y deja en su bus
--     de datos el valor de prueba que se le indico.
--
-- Se comprueba que, tras un pulso en inicio_i, el lector:
--   1) recorre ALE -> START -> espera EOC baja -> espera EOC sube -> lee,
--      sin quedarse bloqueado (si se bloqueara, la simulacion se detendria
--      por el limite --stop-time sin llegar al ultimo mensaje);
--   2) valid_o pulsa exactamente un ciclo de reloj;
--   3) data_o = byte convertido, extendido con ceros a 16 bits (el ADC0808
--      es un conversor UNIPOLAR de 8 bits, sin signo).
-- Se repite con dos valores distintos para confirmar que el modulo vuelve a
-- S_REPOSO y puede disparar una nueva conversion sin reiniciar.
--
-- Ejecucion (GHDL):
--   ghdl -a --std=08 adc0808_reader.vhd adc0808_reader_tb.vhd
--   ghdl -e --std=08 adc0808_reader_tb
--   ghdl -r --std=08 adc0808_reader_tb --wave=adc0808_reader_tb.ghw --stop-time=50us
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity adc0808_reader_tb is
end entity adc0808_reader_tb;

architecture sim of adc0808_reader_tb is

    constant CLK_DIV_TB   : positive := 4;                     -- reducido solo para simular rapido
    constant T_CLK        : time := 20 ns;                     -- reloj de 50 MHz
    constant T_ADC_PERIOD : time := 2 * CLK_DIV_TB * T_CLK;    -- periodo de adc_clk

    signal clk     : std_logic := '0';
    signal rst     : std_logic := '1';
    signal adc_clk : std_logic;
    signal ale     : std_logic;
    signal start   : std_logic;
    signal oe      : std_logic;
    signal eoc     : std_logic := '1';
    signal inicio  : std_logic := '0';
    signal addr    : std_logic_vector(2 downto 0);
    signal data_i  : std_logic_vector(7 downto 0) := (others => '0');
    signal data_o  : std_logic_vector(15 downto 0);
    signal valid   : std_logic;
    signal fin     : boolean := false;

begin

    clk <= not clk after T_CLK/2 when not fin else '0';

    uut : entity work.adc0808_reader
        generic map (
            CLK_DIV    => CLK_DIV_TB,
            CANAL      => 0,
            DATA_WIDTH => 16
        )
        port map (
            clk       => clk,
            rst       => rst,
            adc_clk_o => adc_clk,
            ale_o     => ale,
            start_o   => start,
            oe_o      => oe,
            eoc_i     => eoc,
            inicio_i  => inicio,
            addr_o    => addr,
            data_i    => data_i,
            data_o    => data_o,
            valid_o   => valid
        );

    -- ------------------------------------------------------------------
    -- modelo de comportamiento del ADC0808
    -- ------------------------------------------------------------------
    modelo_adc : process
    begin
        loop
            wait until rising_edge(start);
            wait for 2 * T_ADC_PERIOD;      -- tiempo de adquisicion (EOC baja)
            eoc <= '0';
            wait for 8 * T_ADC_PERIOD;      -- tiempo de conversion (EOC sube)
            eoc <= '1';
        end loop;
    end process modelo_adc;

    -- ------------------------------------------------------------------
    -- estimulo y comprobacion
    -- ------------------------------------------------------------------
    prueba : process
        variable errores : integer := 0;

        procedure convertir(constant byte_prueba : std_logic_vector(7 downto 0)) is
        begin
            data_i <= byte_prueba;
            inicio <= '1';
            wait until rising_edge(clk);
            inicio <= '0';

            wait until valid = '1';
            if data_o /= std_logic_vector(resize(unsigned(byte_prueba), 16)) then
                errores := errores + 1;
                report "FALLO: data_o (" & integer'image(to_integer(unsigned(data_o))) &
                       ") no coincide con el byte de prueba (" &
                       integer'image(to_integer(unsigned(byte_prueba))) & ")" severity warning;
            else
                report "OK: data_o = " & integer'image(to_integer(unsigned(data_o))) &
                       " coincide con el byte convertido" severity note;
            end if;

            wait for (3 * T_CLK) / 2;   -- 1,5 periodos: cae a mitad del ciclo siguiente, ya con valid_o en '0'
            if valid /= '0' then
                errores := errores + 1;
                report "FALLO: valid_o deberia durar solo un ciclo de reloj" severity warning;
            end if;
        end procedure;

    begin
        rst <= '1';
        wait for 5 * T_CLK;
        rst <= '0';
        wait for 5 * T_CLK;

        report "=== primera conversion: byte = 90 (0x5A) ===" severity note;
        convertir(std_logic_vector(to_unsigned(90, 8)));

        wait for 10 * T_CLK;

        report "=== segunda conversion: byte = 195 (0xC3), confirma retorno a S_REPOSO ===" severity note;
        convertir(std_logic_vector(to_unsigned(195, 8)));

        if errores = 0 then
            report "=== adc0808_reader_tb: TODAS LAS COMPROBACIONES CORRECTAS ===" severity note;
        else
            report "=== adc0808_reader_tb: " & integer'image(errores) & " FALLO(S) DETECTADO(S) ===" severity error;
        end if;

        fin <= true;
        wait;
    end process prueba;

end architecture sim;
