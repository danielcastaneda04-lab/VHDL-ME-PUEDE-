--------------------------------------------------------------------------------
-- FIR_Filter_tb.vhd
-- Banco de pruebas del filtro FIR. Fuente: Guia_FIR_FilterDesigner_v5.pdf,
-- seccion 12.6 (tb_FIR_Filter.vhd), reproducido tal cual salvo el nombre de
-- la entidad bajo prueba y el comentario de cabecera.
--
-- Lee el vector de entrada (in.txt) y la salida esperada (ref.txt), generados
-- por matlab/modelo_referencia_S43.m, aplica cada muestra al filtro y
-- comprueba que la salida coincide EXACTAMENTE con el modelo. Cualquier
-- diferencia, aunque sea de un solo bit, indica un error real (ver el
-- apartado 10 / capitulo 13 "Errores Frecuentes" de la Guia).
--
-- IMPORTANTE: FILTER_TAPS aqui debe coincidir siempre con el de FIR_Filter.vhd.
-- Con el filtro tal como se entrega (coeficientes en cero) este banco solo
-- sirve para comprobar la mecanica de lectura de archivos y temporizacion: la
-- salida sera cero para cualquier entrada. La comprobacion real, muestra a
-- muestra contra el modelo entero de MATLAB, es la que se hace DESPUES de
-- pegar los coeficientes reales y regenerar in.txt/ref.txt.
--
-- ghdl -a --std=08 FIR_Filter.vhd FIR_Filter_tb.vhd
-- ghdl -e --std=08 FIR_Filter_tb
-- ghdl -r --std=08 FIR_Filter_tb   (ejecutar desde la carpeta que contiene in.txt y ref.txt)
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;

entity FIR_Filter_tb is
end entity FIR_Filter_tb;

architecture sim of FIR_Filter_tb is
    constant FILTER_TAPS : integer := 27;  -- ajustar junto con FIR_Filter.vhd
    constant INPUT_WIDTH : integer := 16;
    constant T_CLK       : time := 20 ns;  -- reloj de 50 MHz

    signal clk    : std_logic := '0';
    signal fsclk  : std_logic := '0';
    signal data_i : std_logic_vector(INPUT_WIDTH-1 downto 0) := (others => '0');
    signal data_o : std_logic_vector(INPUT_WIDTH-1 downto 0);
    signal fin    : boolean := false;
begin
    clk <= not clk after T_CLK/2 when not fin else '0';

    uut : entity work.FIR_Filter
        generic map (
            FILTER_TAPS  => FILTER_TAPS,
            INPUT_WIDTH  => INPUT_WIDTH,
            COEFF_WIDTH  => 16,
            OUTPUT_WIDTH => 16)
        port map (
            clk    => clk,
            fsclk  => fsclk,
            data_i => data_i,
            data_o => data_o);

    prueba : process
        file f_in, f_ref : text;
        variable l_in, l_ref : line;
        variable v_in, v_ref : integer;
        variable n, errores  : integer := 0;
        variable dif, maxdif : integer := 0;
    begin
        file_open(f_in, "in.txt", read_mode);
        file_open(f_ref, "ref.txt", read_mode);
        wait for 5*T_CLK;

        while not endfile(f_in) loop
            readline(f_in, l_in); read(l_in, v_in);
            readline(f_ref, l_ref); read(l_ref, v_ref);
            data_i <= std_logic_vector(to_signed(v_in, INPUT_WIDTH));
            fsclk <= '1';
            wait for T_CLK;
            fsclk <= '0';
            wait for (FILTER_TAPS + 10) * T_CLK;  -- deja terminar el calculo
            dif := abs(to_integer(signed(data_o)) - v_ref);
            if dif > maxdif then
                maxdif := dif;
            end if;
            if dif /= 0 then
                errores := errores + 1;
                if errores < 5 then
                    report "discrepancia en la muestra " & integer'image(n)
                        & ": VHDL = " & integer'image(to_integer(signed(data_o)))
                        & ", referencia = " & integer'image(v_ref)
                        severity warning;
                end if;
            end if;
            n := n + 1;
        end loop;

        file_close(f_in);
        file_close(f_ref);
        report "muestras comparadas : " & integer'image(n) severity note;
        report "diferencia maxima   : " & integer'image(maxdif) & " LSB" severity note;
        assert errores = 0
            report "El VHDL no coincide con el modelo de MATLAB"
            severity failure;
        report "=== EL FILTRO COINCIDE EXACTAMENTE CON EL MODELO ===" severity note;
        fin <= true;
        wait;
    end process;
end architecture sim;
