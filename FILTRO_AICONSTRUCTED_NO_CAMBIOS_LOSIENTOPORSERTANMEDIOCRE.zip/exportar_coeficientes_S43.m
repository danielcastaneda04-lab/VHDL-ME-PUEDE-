% ---------------------------------------------------------------------
% exportar_coeficientes_S43.m
% Convierte los coeficientes del Filter Designer al bloque VHDL.
% Ejecutar despues de: File > Export > Export to Workspace
% (la variable de coeficientes se llama Num por defecto)
%
% Fuente: Guia_FIR_FilterDesigner_v5.pdf, seccion 8.2 (exportar_coeficientes.m).
% Adaptado a nuestro caso (S = 43, ADC0808 de 8 bits): el UNICO cambio real
% respecto del script de la guia es MAXIN, que pasa de 1023 (conversor de
% 10 bits del ejemplo) a 255 (nuestro ADC0808 de 8 bits). INPUT_WIDTH,
% COEFF_WIDTH y OUTPUT_WIDTH se dejan en 16 porque es la anchura recomendada
% de forma general en la guia, independiente de la resolucion del ADC (el
% codigo de 8 bits se rellena con ceros a la izquierda hasta 16, ver
% adc0808_reader.vhd / top.vhd).
% ---------------------------------------------------------------------
INPUT_WIDTH = 16;
COEFF_WIDTH = 16;
OUTPUT_WIDTH = 16;
MAXIN = 255;   % ADAPTACION AL ADC0808: valor maximo real del codigo del conversor (8 bits -> 255, no 1023)
S = 2^(INPUT_WIDTH + COEFF_WIDTH - OUTPUT_WIDTH - 1); % factor de escala

% --- etapa 1: normalizacion
h = Num(:).';
h = h / sum(h);

% --- etapa 2: escalado y redondeo
c = round(h * S);

% --- etapa 3: correccion de la ganancia en continua
m = ceil(numel(c)/2);
fprintf('correccion aplicada al coeficiente central: %d\n', S - sum(c));
c(m) = c(m) + (S - sum(c));

% --- verificaciones
fprintf('coeficientes  : %d\n', numel(c));
fprintf('suma          : %d (debe ser %d)\n', sum(c), S);
fprintf('minimo/maximo : %d / %d\n', min(c), max(c));
fprintf('suma de |c|   : %d\n', sum(abs(c)));
fprintf('margen acum.  : %.1f veces\n', ...
    2^(INPUT_WIDTH+COEFF_WIDTH-2) / (sum(abs(c))*MAXIN));

if sum(c) ~= S
    error('La suma de los coeficientes no es correcta.');
end
if numel(c) < 23 || numel(c) > 33
    warning('El Laboratorio 2 anuncia que, para cualquier grupo, el numero de coeficientes deberia quedar entre 23 y 33. Revisa el orden elegido en el Filter Designer si te sales de ese rango.');
end
if mod(numel(c),2) ~= 1
    warning('El numero de coeficientes deberia ser impar (Filter Order = numero de coeficientes - 1, elegido par).');
end
if min(c) < -2^(COEFF_WIDTH-1) || max(c) > 2^(COEFF_WIDTH-1)-1
    error('Algun coeficiente no cabe en COEFF_WIDTH bits.');
end
if sum(abs(c))*MAXIN >= 2^(INPUT_WIDTH+COEFF_WIDTH-2)
    error('El acumulador puede desbordarse.');
end

% --- escritura del bloque VHDL, seis valores por linea
fid = fopen('coeficientes.txt','w');
fprintf(fid,'type coefficients is array (0 to %d) of signed(%d downto 0);\n', ...
    numel(c)-1, COEFF_WIDTH-1);
fprintf(fid,'signal coeff_s : coefficients := (\n');
for k = 1:numel(c)
    v = mod(c(k), 2^COEFF_WIDTH); % complemento a dos automatico
    if mod(k-1,6) == 0, fprintf(fid,'    '); end
    if k < numel(c)
        fprintf(fid,'x"%04X", ', v);
    else
        fprintf(fid,'x"%04X");\n', v);
    end
    if mod(k,6) == 0 && k < numel(c), fprintf(fid,'\n'); end
end
fclose(fid);
disp('Archivo coeficientes.txt generado.');
disp('Pega su contenido en FIR_Filter.vhd, en el bloque marcado');
disp('"PEGAR AQUI LOS COEFICIENTES GENERADOS EN MATLAB", y cambia');
disp('FILTER_TAPS (en FIR_Filter.vhd Y en FIR_Filter_tb.vhd) al valor');
fprintf('numel(c) = %d.\n', numel(c));
