--------------------------------------------------------------------------------
-- bin_a_bcd.vhd
-- Convierte un binario sin signo de INPUT_WIDTH bits (aqui, T_decimas, la
-- temperatura en decimas de grado, 0 a 999 en uso normal) en tres digitos
-- BCD mediante el algoritmo doble-dabble (shift-and-add-3).
--
-- ADAPTACION -- NO VIENE DE LAS FUENTES: el encargo del Laboratorio 2 dice
-- "reutilizar bin_a_bcd.vhd y hex7seg.vhd del Laboratorio 1", pero ese
-- archivo no forma parte de los documentos que me diste, asi que no puedo
-- reproducir tu version real. Esta es una implementacion estandar que
-- cumple la funcion descrita (Laboratorio2_Filtro_FIR_Perturbacion_
-- Coherente.pdf, seccion 5.9, punto 4: "presentar la temperatura en HEX2 a
-- HEX0 con la letra C en HEX3"). Si tu bin_a_bcd.vhd del Laboratorio 1 tiene
-- otros puertos o genericos, sustituye este archivo por el tuyo: top.vhd
-- solo necesita tres salidas BCD de 4 bits (centenas, decenas, unidades).
--
-- Con T_decimas = 249 (24,9 C), este modulo entrega:
--   centenas_o = "0010" (2, decenas de grado -> HEX2)
--   decenas_o  = "0100" (4, unidades de grado -> HEX1)
--   unidades_o = "1001" (9, decima de grado   -> HEX0)
-- (los nombres de los puertos siguen la convencion habitual de un BCD de
-- tres digitos: "centenas/decenas/unidades" del NUMERO T_decimas, que al
-- interpretarse como grados.decima son, en ese orden, decenas de grado,
-- unidades de grado y decima de grado).
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity bin_a_bcd is
    generic (
        INPUT_WIDTH : positive := 10   -- cubre 0 a 1023; en uso normal T_decimas <= 999
    );
    port (
        bin_i      : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        centenas_o : out std_logic_vector(3 downto 0);
        decenas_o  : out std_logic_vector(3 downto 0);
        unidades_o : out std_logic_vector(3 downto 0)
    );
end entity bin_a_bcd;

architecture rtl of bin_a_bcd is
begin

    process (bin_i)
        variable reg : unsigned(INPUT_WIDTH+11 downto 0);  -- [centenas|decenas|unidades|binario]
    begin
        reg := (others => '0');
        reg(INPUT_WIDTH-1 downto 0) := unsigned(bin_i);

        for i in 0 to INPUT_WIDTH-1 loop
            if reg(INPUT_WIDTH+3 downto INPUT_WIDTH) > 4 then
                reg(INPUT_WIDTH+3 downto INPUT_WIDTH) :=
                    reg(INPUT_WIDTH+3 downto INPUT_WIDTH) + 3;
            end if;
            if reg(INPUT_WIDTH+7 downto INPUT_WIDTH+4) > 4 then
                reg(INPUT_WIDTH+7 downto INPUT_WIDTH+4) :=
                    reg(INPUT_WIDTH+7 downto INPUT_WIDTH+4) + 3;
            end if;
            if reg(INPUT_WIDTH+11 downto INPUT_WIDTH+8) > 4 then
                reg(INPUT_WIDTH+11 downto INPUT_WIDTH+8) :=
                    reg(INPUT_WIDTH+11 downto INPUT_WIDTH+8) + 3;
            end if;
            reg := shift_left(reg, 1);
        end loop;

        unidades_o <= std_logic_vector(reg(INPUT_WIDTH+3 downto INPUT_WIDTH));
        decenas_o  <= std_logic_vector(reg(INPUT_WIDTH+7 downto INPUT_WIDTH+4));
        centenas_o <= std_logic_vector(reg(INPUT_WIDTH+11 downto INPUT_WIDTH+8));
    end process;

end architecture rtl;
